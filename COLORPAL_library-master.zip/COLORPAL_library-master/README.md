# COLORPAL_library
Libreria NON UFFICIALE per il sensore di colore COLORPAL, costruito dalla PARALLAX

Attualmente è funzionante solo la letura del colore, in componenti RGB. La lettura si effettua attraverso la funzione
``` 
leggiRGB(int& rosso, int& verde, int& blu);
```
Al termine della funzione, i 3 parametri conterranno le componenti RGB rilevate. Per l'inizializzazione del sensore, vedere lo sketch di esempio all'interno della libreria.

Simone Tolomei
